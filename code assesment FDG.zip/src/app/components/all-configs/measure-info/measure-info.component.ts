import { Component } from '@angular/core';

@Component({
  selector: 'app-measure-info',
  templateUrl: './measure-info.component.html',
  styleUrl: './measure-info.component.scss',
})
export class MeasureInfoComponent {}
