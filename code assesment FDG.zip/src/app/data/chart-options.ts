export const CHART_OPTIONS = {
  linkColor: '#313131',
  gradientShade: 'rgba(255, 255, 255, 0)',
  gradientColor: '#31313186',
};
