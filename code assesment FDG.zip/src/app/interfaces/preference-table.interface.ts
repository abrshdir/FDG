import { Sign } from '../enums';

export interface PreferenceTable {
  name: string;
  value: number;
  sign: Sign;
}
