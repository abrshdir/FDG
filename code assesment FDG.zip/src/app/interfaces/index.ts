import { Person2, Cluster } from './person.interface';
import { GraphConfiguration } from './graph-configuration.interface';

export { Person2, GraphConfiguration, Cluster };
