export enum NodeType {
  ATTRIBUTE = 'attribute',
  PERSON = 'person',
}
