export enum Sign {
  GREATER = 'greater',
  EXACT = 'exact',
  LESSER = 'lesser',
  CLOSER = 'closer',
}
